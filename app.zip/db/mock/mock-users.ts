import { User } from '../../models/user';

export const USERS: User[] = [
  { id: 1, name: 'Tony', pass: 'w1' },
  { id: 2, name: 'Frank', pass: 'w2' },
  { id: 3, name: 'Admin', pass: 'pass' }
];