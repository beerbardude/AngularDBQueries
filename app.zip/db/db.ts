'use strict'
/*Initialisierung der DB Verbindung mittels pg library */
//let pool = require('./config');

//export class DB {

  //  getUser(){
        //pool.query("SELECT * from users", function (err, result) {
          //  console.log(result.rows);
            //response.json(result.rows);
        //});

    //}
//}