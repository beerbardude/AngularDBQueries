import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { AuthenticationService } from '../services/authentication.service';
import { MessageService } from '../services/message.service';
import { User } from '../models/user';

@Component({
    moduleId: module.id,
    templateUrl: 'login.component.html'
})

export class LoginComponent implements OnInit {
    @Input() user : User;
    
    //loading = false;
    //returnUrl: string;

    constructor(
        private route: ActivatedRoute,
        //private router: Router,
        private authenticationService: AuthenticationService,
        private messageService: MessageService
    ) { }

    ngOnInit(): void {
        this.user = new User();
        // reset login status
        //this.authenticationService.logout();

        // get return url from route parameters or default to '/'
        //this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    }

    login() {
        if(typeof this.user.name !== 'undefined') {
        this.authenticationService.login(this.user)
            .subscribe(data => {
            this.messageService.info("user found");
            });
        }
        else {
            this.messageService.error("undefined name");            
        }
        
        //this.loading = true;        
        //this.authenticationService.login(this.user.name, this.user.pass)
          //  .subscribe(
            //    data => {
              //      this.router.navigate([this.returnUrl]);
//                },
  //              error => {
    //                this.messageService.error(error);
      //              this.loading = false;
        //        });
    }
}
