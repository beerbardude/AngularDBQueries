import { User } from './user';

export const USERS: User[] = [
  { id: 1, name: 'Tony', pass: 'w' },
  { id: 2, name: 'Frank', pass: 'w' },
  { id: 3, name: 'Admin', pass: 'pass' }
];