export class Customer {
    id: number;
    lastname: string;
    firstname: string;
    street: string;
    housenumber: string;
    postcode: number;
    town: string;
    country: string;
    language: string;
}